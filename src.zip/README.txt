Compile: cs3110 compile -p graphics view
Run: cs3110 run view

Important: the program has a window size of 880x920, so the game is difficult to
play and appreciate on a screen smaller than that.

Good luck against the AI!

Use mouse for both navigation in menus and during play.
